# Mapperly route performance replay, 25 November 2026

This archive preserves 262 paired measurements over 42 route fixtures. Start with
`validated/analysis-summary.txt` for the results and `validated/comparison.csv`
for the per-route table. These paths are relative to this README. Each cold and
warm pair uses the same Lua runtime. Host seconds measure this offline benchmark.
The 60 fps estimate models scheduling, and journey seconds estimate character travel.

## Reproduce the paired table

Extract the ZIP at the root of a fresh copy of the matching Mapperly checkout,
preserving the archived `output/` paths. From the checkout root run:

```powershell
python tools/compare_route_performance.py --label validated --report-only
```

This uses the archived baseline and replay measurements to regenerate
`validated/comparison.csv` and print timing summaries. It requires only Python
and the checkout's comparison and benchmark scripts.

## Measure the planner again

Use a checkout whose planner file bytes match the SHA-256 digests in
`validated/sources.json`. Install the development dependencies in the active
Python environment, then give the replay its own label:

```powershell
python -m pip install -r requirements-dev.txt
python tools/compare_route_performance.py --label replay-local
```

The runner uses Lua 5.1 through Lupa. It loads the saved coordinates and route
options, writes cold/warm measurements under `replay-local/`, and compares them
with the archived baseline. An interrupted run can resume with the same label
when its source hashes match. Timing samples will vary with the host and load.

`../route-matrix-2026-11-25/matrix.json` records the baseline coordinates,
methodology and SHA-256 digests for all 29 frozen modules in `baseline-modules/`.
`../route-matrix-2026-11-25/benchmark-results.json` contains the original
measurements. The validated run's source manifest covers 31 modules from the
matching checkout. Supplemental files preserve road and loading checks, native
dependency verification, the test summary, and the R27/R38 investigations.
