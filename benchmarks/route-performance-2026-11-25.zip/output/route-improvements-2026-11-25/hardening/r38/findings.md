# R38 tram itinerary and dock cache hardening

No production file was edited. The staged `TravelNetwork.lua` changes only the per-plan ground-path cache key and its explanatory comment.

## R38 finding

One targeted actual Lua plan reproduced Goldshire → Stormwind → Ironforge → Stormwind → Auberdine → Astranaar, including both opposing Deeprun Tram rides and boat `transport:11616:18:6`. The returned walking distance was 6,414.9471 yards and its estimated journey time was 1,637.4210 seconds. These are itinerary values, not a new latency comparison.

The Stormwind city entrance reached from Elwynn is `(1453,0.7601920149056738,0.9226594379312946)`, root walking region **52**. The native harbour descent `7095901453` begins at `(1453,0.39970419195553747,0.4873858707059307)`, region **36**, and ends in region **1**. The boarding pier `7095901454` starts in region 1.

The reverse tram arrives at `(1453,0.6899851741348509,0.3094082911753022)`, region **36**. Existing `Trams.Access` permits onward city wayfinding after that arrival. The selected plan uses a portal-guidance leg to the native boarding pier and then follows the pier. It does not demonstrate a verified pedestrian connection from entrance region 52 to the harbour.

Instrumenting per-plan cached portal success reused inside an `allowPortal=false` dock middle produced **zero such reuses for this R38 plan**. The cache issue below is independently reproducible but is not the cause of R38's two rides.

Removing both rides by adding a virtual station would invent the missing city walk or imply the player remained in the city after entering the tram instance. No such change is staged. A safer future R38 improvement requires supported Stormwind pedestrian coverage or a separately designed, explicit city-navigation policy.

## Independent cache defect and staged fix

`groundPath` previously memoized only map and endpoint coordinates. A normal tram approach can return portal bearings where the root cells are disconnected. A later dock composition with the same coordinates requests `allowPortal=false`, yet could reuse that portal-bearing path. The reverse also occurs: a strict-middle failure could suppress a valid normal tram approach.

The staged key appends `:strict` for `allowPortal=false`, otherwise `:portal`. Fine-grid caches, terrain permissions, transport eligibility, and source data remain unchanged.

`tram_context_hardening.py` uses the real Terrain, Structures, Transports, and Trams code with small synthetic maps and explicit fixture floors/services. It verifies:

- An earlier successful tram bearing cannot authorize a dock middle across a blocked wall.
- An earlier strict-middle failure cannot suppress a later valid tram bearing.
- One-way tram direction stays one-way.
- Faction gating and disabling trams do not invent alternate city walks.
- A valid strict dock approach retains every supplied native pier point.

Run the staged candidate:

```powershell
python output/route-improvements-2026-11-25/hardening/r38/tram_context_hardening.py
```

The candidate passes all five tests. Run `--source TravelNetwork.lua` to reproduce the two expected failures against the unchanged production implementation.
